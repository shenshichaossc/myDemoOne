CREATE TRIGGER axcenter_channel_user2_update_trigger
  BEFORE UPDATE
  ON channel_user2
  FOR EACH ROW
  begin
-- 如果orgPlatId字段为空，给该字段赋值
if (new.orgPlatId='' or  new.orgPlatId is null)  then
set new.orgPlatId='100';
set new.subUserType='0';
end if;
 
end;

