CREATE VIEW 订单合并表 AS
  SELECT
    `a`.`uuid`              AS `uuid`,
    `a`.`timeid`            AS `timeid`,
    `a`.`orderBelongType`   AS `orderBelongType`,
    `a`.`orderCustomerType` AS `orderCustomerType`,
    `a`.`companyUuid`       AS `companyUuid`,
    `a`.`storeUuid`         AS `storeUuid`,
    `a`.`payMoney`          AS `payMoney`,
    `b`.`orderid`           AS `orderid`,
    `b`.`buyNum`            AS `buyNum`
  FROM (`anxun_center_500`.`订单中间表1` `a`
    JOIN `anxun_center_500`.`商品数` `b` ON ((`a`.`uuid` = `b`.`orderid`)));

