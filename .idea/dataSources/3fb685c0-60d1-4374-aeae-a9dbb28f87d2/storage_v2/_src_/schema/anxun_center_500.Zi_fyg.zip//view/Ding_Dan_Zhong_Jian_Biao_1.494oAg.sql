CREATE VIEW 订单中间表1 AS
  SELECT
    `anxun_center_500`.`order_main`.`uuid`                             AS `uuid`,
    date_format(`anxun_center_500`.`order_main`.`orderTime`, '%Y%m%d') AS `timeid`,
    `anxun_center_500`.`order_main`.`orderBelongType`                  AS `orderBelongType`,
    `anxun_center_500`.`order_main`.`orderCustomerType`                AS `orderCustomerType`,
    `anxun_center_500`.`order_main`.`companyUuid`                      AS `companyUuid`,
    `anxun_center_500`.`order_main`.`storeUuid`                        AS `storeUuid`,
    `anxun_center_500`.`order_main`.`orgPlatId`                        AS `orgPlatId`,
    `anxun_center_500`.`order_main`.`payMoney`                         AS `payMoney`
  FROM `anxun_center_500`.`order_main`
  WHERE
    ((`anxun_center_500`.`order_main`.`subOrder` = 1) AND (`anxun_center_500`.`order_main`.`orderCustomerType` <> 0));

