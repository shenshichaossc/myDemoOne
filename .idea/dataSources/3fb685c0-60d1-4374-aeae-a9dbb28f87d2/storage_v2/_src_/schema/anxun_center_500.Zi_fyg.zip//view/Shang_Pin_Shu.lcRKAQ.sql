CREATE VIEW 商品数 AS
  SELECT
    `anxun_center_500`.`order_detail`.`orderMainUuid` AS `orderid`,
    sum(`anxun_center_500`.`order_detail`.`buyNum`)   AS `buyNum`
  FROM `anxun_center_500`.`order_detail`
  GROUP BY `anxun_center_500`.`order_detail`.`orderMainUuid`;

