CREATE VIEW basicdata_area_city_v AS
  SELECT
    str_to_date(`a`.`opeTime`, '%Y-%m-%d %H:%i:%s') AS `lastM`,
    `a`.`uuid`                                      AS `uuid`,
    `a`.`oper`                                      AS `oper`,
    `a`.`opeTime`                                   AS `opeTime`,
    `a`.`delFlag`                                   AS `delFlag`,
    `a`.`provinceUuid`                              AS `provinceUuid`,
    `a`.`cityName`                                  AS `cityName`,
    `a`.`areaNumber`                                AS `areaNumber`,
    `a`.`postCode`                                  AS `postCode`,
    `a`.`available`                                 AS `available`,
    `a`.`stationCode`                               AS `stationCode`,
    `a`.`stationName`                               AS `stationName`,
    `a`.`enName`                                    AS `enName`,
    `a`.`sapCode`                                   AS `sapCode`
  FROM `anxun_center_500`.`basicdata_area_city` `a`;

