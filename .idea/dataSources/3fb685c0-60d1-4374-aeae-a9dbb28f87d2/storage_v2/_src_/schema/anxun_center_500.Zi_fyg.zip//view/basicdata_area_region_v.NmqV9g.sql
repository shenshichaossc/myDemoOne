CREATE VIEW basicdata_area_region_v AS
  SELECT
    str_to_date(`a`.`opeTime`, '%Y-%m-%d %H:%i:%s') AS `lastM`,
    `a`.`uuid`                                      AS `uuid`,
    `a`.`oper`                                      AS `oper`,
    `a`.`opeTime`                                   AS `opeTime`,
    `a`.`delFlag`                                   AS `delFlag`,
    `a`.`cityUuid`                                  AS `cityUuid`,
    `a`.`regionName`                                AS `regionName`,
    `a`.`zipcode`                                   AS `zipcode`,
    `a`.`cityCode`                                  AS `cityCode`,
    `a`.`available`                                 AS `available`,
    `a`.`stationCode`                               AS `stationCode`,
    `a`.`stationName`                               AS `stationName`,
    `a`.`enName`                                    AS `enName`,
    `a`.`sapCode`                                   AS `sapCode`
  FROM `anxun_center_500`.`basicdata_area_region` `a`;

