CREATE VIEW basicdata_area_street_v AS
  SELECT
    str_to_date(`a`.`opeTime`, '%Y-%m-%d %H:%i:%s') AS `lastM`,
    `a`.`uuid`                                      AS `uuid`,
    `a`.`delFlag`                                   AS `delFlag`,
    `a`.`opeTime`                                   AS `opeTime`,
    `a`.`oper`                                      AS `oper`,
    `a`.`regionUuid`                                AS `regionUuid`,
    `a`.`streetName`                                AS `streetName`,
    `a`.`areaNumber`                                AS `areaNumber`,
    `a`.`postCode`                                  AS `postCode`,
    `a`.`available`                                 AS `available`,
    `a`.`stationCode`                               AS `stationCode`,
    `a`.`stationName`                               AS `stationName`,
    `a`.`enName`                                    AS `enName`,
    `a`.`sapCode`                                   AS `sapCode`,
    `a`.`deliveryAreaCode`                          AS `deliveryAreaCode`
  FROM `anxun_center_500`.`basicdata_area_street` `a`;

