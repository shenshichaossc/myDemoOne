CREATE VIEW branch_company_v AS
  SELECT
    str_to_date(`a`.`opeTime`, '%Y-%m-%d %H:%i:%s') AS `lastM`,
    `a`.`uuid`                                      AS `uuid`,
    `a`.`delFlag`                                   AS `delFlag`,
    `a`.`opeTime`                                   AS `opeTime`,
    `a`.`oper`                                      AS `oper`,
    `a`.`addLimit`                                  AS `addLimit`,
    `a`.`companyName`                               AS `companyName`,
    `a`.`companyNo`                                 AS `companyNo`,
    `a`.`normalLimit`                               AS `normalLimit`,
    `a`.`state`                                     AS `state`,
    `a`.`address`                                   AS `address`,
    `a`.`city`                                      AS `city`,
    `a`.`mobile`                                    AS `mobile`,
    `a`.`name`                                      AS `name`,
    `a`.`province`                                  AS `province`,
    `a`.`region`                                    AS `region`,
    `a`.`street`                                    AS `street`,
    `a`.`branchUuid`                                AS `branchUuid`,
    `a`.`businessId`                                AS `businessId`,
    `a`.`type`                                      AS `type`,
    `a`.`parentUuid`                                AS `parentUuid`,
    `a`.`costCenterUuid`                            AS `costCenterUuid`,
    `a`.`profitCenterUuid`                          AS `profitCenterUuid`
  FROM `anxun_center_500`.`branch_company` `a`;

