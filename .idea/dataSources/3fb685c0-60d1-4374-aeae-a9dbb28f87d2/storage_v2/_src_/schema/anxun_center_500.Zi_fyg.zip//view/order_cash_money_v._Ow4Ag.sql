CREATE VIEW order_cash_money_v AS
  SELECT
    str_to_date(`a`.`opeTime`, '%Y-%m-%d %H:%i:%s') AS `lastM`,
    `a`.`uuid`                                      AS `uuid`,
    `a`.`delFlag`                                   AS `delFlag`,
    `a`.`opeTime`                                   AS `opeTime`,
    `a`.`oper`                                      AS `oper`,
    `a`.`cashCustomerUuid`                          AS `cashCustomerUuid`,
    `a`.`cashMentBillNo`                            AS `cashMentBillNo`,
    `a`.`cashMoney`                                 AS `cashMoney`,
    `a`.`cashTime`                                  AS `cashTime`,
    `a`.`note`                                      AS `note`,
    `a`.`orderMainUuid`                             AS `orderMainUuid`,
    `a`.`payCustomerUuid`                           AS `payCustomerUuid`,
    `a`.`state`                                     AS `state`,
    `a`.`pushCrm`                                   AS `pushCrm`,
    `a`.`orderMainSubUuid`                          AS `orderMainSubUuid`,
    `a`.`paySerialNum`                              AS `paySerialNum`,
    `a`.`cashType`                                  AS `cashType`,
    `a`.`payType`                                   AS `payType`,
    `a`.`payCustomerName`                           AS `payCustomerName`,
    `a`.`companyUuid`                               AS `companyUuid`,
    `a`.`storeUuid`                                 AS `storeUuid`,
    `a`.`creditPay`                                 AS `creditPay`
  FROM `anxun_center_500`.`order_cash_money` `a`;

