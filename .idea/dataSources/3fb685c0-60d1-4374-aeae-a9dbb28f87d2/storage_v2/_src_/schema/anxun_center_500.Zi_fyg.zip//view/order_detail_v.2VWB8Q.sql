CREATE VIEW order_detail_v AS
  SELECT
    str_to_date(`a`.`opeTime`, '%Y-%m-%d %H:%i:%s') AS `lastM`,
    `a`.`uuid`                                      AS `uuid`,
    `a`.`opeTime`                                   AS `opeTime`,
    `a`.`basePrice`                                 AS `basePrice`,
    `a`.`buyNum`                                    AS `buyNum`,
    `a`.`finalPrice`                                AS `finalPrice`,
    `a`.`orderMainUuid`                             AS `orderMainUuid`,
    `a`.`productGroupUuid`                          AS `productGroupUuid`,
    `a`.`productName`                               AS `productName`,
    `a`.`productUuid`                               AS `productUuid`,
    `a`.`productNo`                                 AS `productNo`,
    `a`.`promotionPrice`                            AS `promotionPrice`,
    `a`.`state`                                     AS `state`,
    `a`.`productType`                               AS `productType`,
    `a`.`freeMoney`                                 AS `freeMoney`,
    `a`.`payMoney`                                  AS `payMoney`
  FROM `anxun_center_500`.`order_detail` `a`;

