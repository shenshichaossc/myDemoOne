CREATE VIEW order_main_address_v AS
  SELECT
    str_to_date(`a`.`opeTime`, '%Y-%m-%d %H:%i:%s') AS `lastM`,
    `a`.`uuid`                                      AS `uuid`,
    `a`.`delFlag`                                   AS `delFlag`,
    `a`.`opeTime`                                   AS `opeTime`,
    `a`.`oper`                                      AS `oper`,
    `a`.`address`                                   AS `address`,
    `a`.`city`                                      AS `city`,
    `a`.`mobile`                                    AS `mobile`,
    `a`.`name`                                      AS `name`,
    `a`.`orderMainUuid`                             AS `orderMainUuid`,
    `a`.`postCode`                                  AS `postCode`,
    `a`.`province`                                  AS `province`,
    `a`.`region`                                    AS `region`,
    `a`.`regionName`                                AS `regionName`,
    `a`.`tel`                                       AS `tel`,
    `a`.`street`                                    AS `street`,
    `a`.`addressCode`                               AS `addressCode`
  FROM `anxun_center_500`.`order_main_address` `a`;

