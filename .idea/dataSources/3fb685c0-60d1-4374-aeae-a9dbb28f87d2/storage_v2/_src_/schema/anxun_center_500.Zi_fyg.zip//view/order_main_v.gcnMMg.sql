CREATE VIEW order_main_v AS
  SELECT
    str_to_date(`anxun_center_500`.`order_main`.`opeTime`, '%Y-%m-%d %H:%i:%s') AS `lastM`,
    `anxun_center_500`.`order_main`.`uuid`                                      AS `uuid`,
    `anxun_center_500`.`order_main`.`customerUuid`                              AS `customerUuid`,
    `anxun_center_500`.`order_main`.`customerName`                              AS `customerName`,
    `anxun_center_500`.`order_main`.`payTime`                                   AS `payTime`,
    `anxun_center_500`.`order_main`.`orderType`                                 AS `orderType`,
    `anxun_center_500`.`order_main`.`payMoney`                                  AS `payMoney`,
    `anxun_center_500`.`order_main`.`orderBelongType`                           AS `orderbelongtype`,
    `anxun_center_500`.`order_main`.`orderCustomerType`                         AS `ordercustomertype`,
    `anxun_center_500`.`order_main`.`state`                                     AS `state`,
    `anxun_center_500`.`order_main`.`storeUuid`                                 AS `storeUuid`,
    `anxun_center_500`.`order_main`.`subOrder`                                  AS `subOrder`,
    `anxun_center_500`.`order_main`.`orgPlatId`                                 AS `orgPlatId`,
    `anxun_center_500`.`order_main`.`companyUuid`                               AS `companyUuid`,
    `anxun_center_500`.`order_main`.`buyerOrgPlatId`                            AS `buyerOrgPlatId`
  FROM `anxun_center_500`.`order_main`;

