CREATE VIEW price_provide_baseinfo_v AS
  SELECT
    str_to_date(`a`.`opeTime`, '%Y-%m-%d %H:%i:%s') AS `lastM`,
    `a`.`uuid`                                      AS `uuid`,
    `a`.`costPrice`                                 AS `costPrice`,
    `a`.`productUuid`                               AS `productUuid`,
    `a`.`productNo`                                 AS `productNo`
  FROM `anxun_center_500`.`price_provide_baseinfo` `a`;

