CREATE VIEW product_brand_v AS
  SELECT
    str_to_date(`a`.`opeTime`, '%Y-%m-%d %H:%i:%s') AS `lastM`,
    `a`.`uuid`                                      AS `uuid`,
    `a`.`brandNo`                                   AS `brandNo`,
    `a`.`brandName`                                 AS `brandName`,
    `a`.`brandEnName`                               AS `brandEnName`,
    `a`.`auditor`                                   AS `auditor`,
    `a`.`orgPlatId`                                 AS `orgPlatId`
  FROM `anxun_center_500`.`product_brand` `a`
  WHERE (`a`.`orgPlatId` <> 100);

