CREATE VIEW product_category_platform_v AS
  SELECT
    str_to_date(`a`.`opeTime`, '%Y-%m-%d %H:%i:%s') AS `lastM`,
    `a`.`uuid`                                      AS `uuid`,
    `a`.`delFlag`                                   AS `delFlag`,
    `a`.`opeTime`                                   AS `opeTime`,
    `a`.`oper`                                      AS `oper`,
    `a`.`categoryName`                              AS `categoryName`,
    `a`.`categoryNo`                                AS `categoryNo`,
    `a`.`categoryNote`                              AS `categoryNote`,
    `a`.`categoryUrl`                               AS `categoryUrl`,
    `a`.`fullpath`                                  AS `fullpath`,
    `a`.`parentUuid`                                AS `parentUuid`,
    `a`.`position`                                  AS `position`,
    `a`.`state`                                     AS `state`,
    `a`.`tagCategoryUuid`                           AS `tagCategoryUuid`,
    `a`.`tagValue`                                  AS `tagValue`,
    `a`.`navImage`                                  AS `navImage`,
    `a`.`wxSynchState`                              AS `wxSynchState`,
    `a`.`categorySapNo`                             AS `categorySapNo`,
    `a`.`propNum`                                   AS `propNum`
  FROM `anxun_center_500`.`product_category_platform` `a`;

