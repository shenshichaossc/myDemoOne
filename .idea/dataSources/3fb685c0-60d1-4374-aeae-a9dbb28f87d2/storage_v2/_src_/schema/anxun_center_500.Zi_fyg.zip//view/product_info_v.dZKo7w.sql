CREATE VIEW product_info_v AS
  SELECT
    str_to_date(`a`.`opeTime`, '%Y-%m-%d %H:%i:%s') AS `lastM`,
    `a`.`uuid`                                      AS `uuid`,
    `a`.`delFlag`                                   AS `delFlag`,
    `a`.`opeTime`                                   AS `opeTime`,
    `a`.`oper`                                      AS `oper`,
    `a`.`adviceNote`                                AS `adviceNote`,
    `a`.`enable`                                    AS `enable`,
    `a`.`productName`                               AS `productName`,
    `a`.`promotionUuid`                             AS `promotionUuid`,
    `a`.`terminalType`                              AS `terminalType`,
    `a`.`productUuid`                               AS `productUuid`
  FROM `anxun_center_500`.`product_info` `a`;

