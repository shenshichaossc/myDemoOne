CREATE VIEW sale_org_v AS
  SELECT
    str_to_date(`a`.`opeTime`, '%Y-%m-%d %H:%i:%s') AS `lastM`,
    `a`.`uuid`                                      AS `uuid`,
    `a`.`oper`                                      AS `oper`,
    `a`.`opeTime`                                   AS `opeTime`,
    `a`.`delFlag`                                   AS `delFlag`,
    `a`.`saleOrgCode`                               AS `saleOrgCode`,
    `a`.`saleOrgDesc`                               AS `saleOrgDesc`,
    `a`.`companyCode`                               AS `companyCode`,
    `a`.`companyCodeDesc`                           AS `companyCodeDesc`,
    `a`.`saleOfficeCode`                            AS `saleOfficeCode`,
    `a`.`saleOfficeDesc`                            AS `saleOfficeDesc`,
    `a`.`saleGroup`                                 AS `saleGroup`,
    `a`.`saleGroupDesc`                             AS `saleGroupDesc`,
    `a`.`QAFlag`                                    AS `QAFlag`,
    `a`.`QALog`                                     AS `QALog`,
    `a`.`JLFlag`                                    AS `JLFlag`,
    `a`.`JLLog`                                     AS `JLLog`,
    `a`.`companyUuid`                               AS `companyUuid`
  FROM `anxun_center_500`.`sale_org` `a`;

