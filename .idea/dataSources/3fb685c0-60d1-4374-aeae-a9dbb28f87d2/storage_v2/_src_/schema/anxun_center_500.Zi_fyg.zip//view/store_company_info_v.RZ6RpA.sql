CREATE VIEW store_company_info_v AS
  SELECT
    str_to_date(`a`.`opeTime`, '%Y-%m-%d %H:%i:%s') AS `lastM`,
    `a`.`uuid`                                      AS `uuid`,
    `a`.`accountUuid`                               AS `accountUuid`,
    `a`.`addressName`                               AS `addressName`,
    `a`.`city`                                      AS `city`,
    `a`.`companyAddress`                            AS `companyAddress`,
    `a`.`companyName`                               AS `companyName`,
    `a`.`province`                                  AS `province`,
    `a`.`region`                                    AS `region`,
    `a`.`registerMoney`                             AS `registerMoney`,
    `a`.`saleProducts`                              AS `saleProducts`,
    `a`.`storeUuid`                                 AS `storeUuid`,
    `a`.`street`                                    AS `street`
  FROM `anxun_center_500`.`store_company_info` `a`;

